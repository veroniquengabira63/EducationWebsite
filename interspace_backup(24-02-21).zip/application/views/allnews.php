<?php include 'common/header.php'; ?>
<!-- System stylesheets  -->
       

<!-- Body  -->

<div class="container-fluid mt-5">
  <div class="row">
    <div class="col-md-9 col-sm-12 news_card">
        <div class="row">

            <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                <div class="card">
                    <img src="assets/images/news.jpg" alt="Your_image" class="card-img-top img-fluid zoom">
                    <div class="card-block card-space">
                        <div class="row">
                            <div class="col-12 date">
                                <span>17th September' 2020</span>
                            </div>
                        </div>
                        <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                        <p>Trinamool Congress of West Bengal opposed the scheduled dates of UGC-NET examinations 2020 announced </p>
                        <div class="col-12 text-right">
                            <span class="label label-green">Read more</span>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                <div class="card">
                    <img src="assets/images/news.jpg" alt="Your_image" class="card-img-top img-fluid zoom">
                    <div class="card-block card-space">
                        <div class="row">
                            <div class="col-12 date">
                                <span>17th September' 2020</span>
                            </div>
                        </div>
                        <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                        <p>Trinamool Congress of West Bengal opposed the scheduled dates of UGC-NET examinations 2020 announced </p>
                        <div class="col-12 text-right">
                            <span class="label label-green">Read more</span>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                <div class="card">
                    <img src="assets/images/news.jpg" alt="Your_image" class="card-img-top img-fluid zoom">
                    <div class="card-block card-space">
                        <div class="row">
                            <div class="col-12 date">
                                <span>17th September' 2020</span>
                            </div>
                        </div>
                        <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                        <p>Trinamool Congress of West Bengal opposed the scheduled dates of UGC-NET examinations 2020 announced </p>
                        <div class="col-12 text-right">
                            <span class="label label-green">Read more</span>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                <div class="card">
                    <img src="assets/images/news.jpg" alt="Your_image" class="card-img-top img-fluid zoom">
                    <div class="card-block card-space">
                        <div class="row">
                            <div class="col-12 date">
                                <span>17th September' 2020</span>
                            </div>
                        </div>
                        <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                        <p>Trinamool Congress of West Bengal opposed the scheduled dates of UGC-NET examinations 2020 announced </p>
                        <div class="col-12 text-right">
                            <span class="label label-green">Read more</span>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                <div class="card">
                    <img src="assets/images/news.jpg" alt="Your_image" class="card-img-top img-fluid zoom">
                    <div class="card-block card-space">
                        <div class="row">
                            <div class="col-12 date">
                                <span>17th September' 2020</span>
                            </div>
                        </div>
                        <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                        <p>Trinamool Congress of West Bengal opposed the scheduled dates of UGC-NET examinations 2020 announced </p>
                        <div class="col-12 text-right">
                            <span class="label label-green">Read more</span>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                <div class="card">
                    <img src="assets/images/news.jpg" alt="Your_image" class="card-img-top img-fluid zoom">
                    <div class="card-block card-space">
                        <div class="row">
                            <div class="col-12 date">
                                <span>17th September' 2020</span>
                            </div>
                        </div>
                        <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                        <p>Trinamool Congress of West Bengal opposed the scheduled dates of UGC-NET examinations 2020 announced </p>
                        <div class="col-12 text-right">
                            <span class="label label-green">Read more</span>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                <div class="card">
                    <img src="assets/images/news.jpg" alt="Your_image" class="card-img-top img-fluid zoom">
                    <div class="card-block card-space">
                        <div class="row">
                            <div class="col-12 date">
                                <span>17th September' 2020</span>
                            </div>
                        </div>
                        <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                        <p>Trinamool Congress of West Bengal opposed the scheduled dates of UGC-NET examinations 2020 announced </p>
                        <div class="col-12 text-right">
                            <span class="label label-green">Read more</span>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                <div class="card">
                    <img src="assets/images/news.jpg" alt="Your_image" class="card-img-top img-fluid zoom">
                    <div class="card-block card-space">
                        <div class="row">
                            <div class="col-12 date">
                                <span>17th September' 2020</span>
                            </div>
                        </div>
                        <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                        <p>Trinamool Congress of West Bengal opposed the scheduled dates of UGC-NET examinations 2020 announced </p>
                        <div class="col-12 text-right">
                            <span class="label label-green">Read more</span>
                            </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                <div class="card">
                    <img src="assets/images/news.jpg" alt="Your_image" class="card-img-top img-fluid zoom">
                    <div class="card-block card-space">
                        <div class="row">
                            <div class="col-12 date">
                                <span>17th September' 2020</span>
                            </div>
                        </div>
                        <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                        <p>Trinamool Congress of West Bengal opposed the scheduled dates of UGC-NET examinations 2020 announced </p>
                        <div class="col-12 text-right">
                            <span class="label label-green">Read more</span>
                            </div>
                    </div>
                </div>
            </div>
            
        </div>

            <!-- Pegination  -->
            <div class="row">
                <div class="col-md-9 d-none d-md-block"></div>
                <div class="col-12 col-md-3">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                </ul>
                </div>
            </div>

    </div>  


   
    


    <!-- Notification Sidebar  -->
<div class="col-sm-12 col-md-3 mr-auto ml-auto rd-more">

    <div class="featured-news">
        <div class="card bg-success text-white text-left w-100 mb-2">
            <div class="card-head font-weight-bold my-2 mx-2"> <i class="fa fa-bell-o mr-2 fa-lg" aria-hidden="true"></i>FEATURED NEWS</div>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="assets/images/news.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-8">
                <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                <span>17th September' 2020</span>
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="assets/images/news.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-8">
                <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                <span>17th September' 2020</span>
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="assets/images/news.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-8">
                <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                <span>17th September' 2020</span>
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="assets/images/news.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-8">
                <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                <span>17th September' 2020</span>
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="assets/images/news.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-8">
                <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                <span>17th September' 2020</span>
            </div>
        </div>

    </div>


    <div class="featured-news">
        <div class="card bg-success text-white text-left w-100 mb-2">
            <div class="card-head font-weight-bold my-2 mx-2"> <i class="fa fa-bell-o mr-2 fa-lg" aria-hidden="true"></i>TRENDING NEWS</div>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="assets/images/news.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-8">
                <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                <span>17th September' 2020</span>
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="assets/images/news.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-8">
                <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                <span>17th September' 2020</span>
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="assets/images/news.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-8">
                <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                <span>17th September' 2020</span>
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="assets/images/news.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-8">
                <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                <span>17th September' 2020</span>
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="assets/images/news.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-8">
                <a class="card-title" href="#"> UGC-NET Exam 2020 Dates to clash with Durga Puja; Trinamool Congress opposes NTA's De...</a>
                <span>17th September' 2020</span>
            </div>
        </div>

    </div>
   

   </div>
      
</div>

</div> 


<!-- More news bottom  -->
<div class="container-fluid">
  <div class="row">
  <div class="col-md col-sm-12 ">
  <div class="card mt-4 shadow "  data-aos="fade-zoom-in"
       data-aos-easing="ease-in-back"
       data-aos-delay="100"
       data-aos-offset="0">
    <img class="card-img " src="https://images.static-collegedunia.com/public/asset/img/exam/news/news6.jpg?tr=w-275,h-160,c-force" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">August 10, 2020</h5>
      <p class="card-text">JEE Advanced 2020: Exam to be ..</p>
      <a href="#" class="btn btn-success">Explore More</a>
    </div>
  </div>
  </div>
  <div class="col-md col-sm-12">
  <div class="card mt-4 shadow green"  data-aos="fade-zoom-in"
       data-aos-easing="ease-in-back"
       data-aos-delay="150"
       data-aos-offset="0">
    <img class="card-img " src="https://images.static-collegedunia.com/public/asset/img/exam/news/news12.jpg?tr=w-275,h-160,c-force" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">July 23, 2020</h5>
      <p class="card-text">JEE Advanced 2020 to be condu ..</p>
      <a href="#" class="btn btn-success">Explore More</a>
    </div>
  </div>
  </div>
  
  <div class="col-md col-sm-12">
  <div class="card mt-4 shadow green"  data-aos="fade-zoom-in"
       data-aos-easing="ease-in-back"
       data-aos-delay="200"
       data-aos-offset="0">
    <img class="card-img " src="https://images.static-collegedunia.com/public/asset/img/exam/news/news9.jpg?tr=w-275,h-160,c-force" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">July 20, 2020</h5>
      <p class="card-text">National Test Abhyas App Delhi ..</p>
      <a href="#" class="btn btn-success">Explore More</a>
    </div>
  </div>
  </div>
  <div class="col-md col-sm-12">
  <div class="card mt-4 shadow green"  data-aos="fade-zoom-in"
       data-aos-easing="ease-in-back"
       data-aos-delay="250"
       data-aos-offset="0">
    <img class="card-img " src="https://images.static-collegedunia.com/public/asset/img/exam/news/news11.jpg?tr=w-275,h-160,c-force" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">July 20, 2020</h5>
      <p class="card-text">JEE Advanced 2020 Syllabus to ..</p>
      <a href="#" class="btn btn-success">Explore More</a>
    </div>
  </div>
  </div>
  
  <div class="col-md col-sm-12">
    <div class="card mt-4 shadow green"  data-aos="fade-zoom-in"
         data-aos-easing="ease-in-back"
         data-aos-delay="250"
         data-aos-offset="0">
      <img class="card-img " src="https://images.static-collegedunia.com/public/asset/img/exam/news/news11.jpg?tr=w-275,h-160,c-force" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title">July 20, 2020</h5>
        <p class="card-text">JEE Advanced 2020 Syllabus to ..</p>
        <a href="#" class="btn btn-success">Explore More</a>
      </div>
    </div>
    </div>
    
</div>
</div> 

<?php include 'common/footer.php'; ?>
<script  src="<?php echo base_url() ?>assets/js/index.js"></script>