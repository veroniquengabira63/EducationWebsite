<div class="sidebar-navigation">

  <ul>

    <li><a href="<?php echo base_url() ?>/admin/add_college"><i class="fa fa-calendar mr-10"></i> Add College</a></li>

    <li><a href="<?php echo base_url() ?>/admin/add_course_degree"><i class="fa fa-calendar mr-10"></i> Add Course Degree</a></li>

    <li><a href="<?php echo base_url() ?>/admin/add_course"><i class="fa fa-calendar mr-10"></i> Add Course</a></li>


    <li><a href="<?php echo base_url() ?>admin/view_course_degree"> <i class="fa fa-eye mr-10"></i> View Course Degree</a></li>

    <li><a href="<?php echo base_url() ?>admin/view_course"> <i class="fa fa-eye mr-10"></i> View Course </a></li>

    <li><a href="<?php echo base_url() ?>admin/view_college"> <i class="fa fa-eye mr-10"></i> View Colleges </a></li>

    <li><a href="<?php echo base_url() ?>admin/edit_profile"> <i class="fa fa-cog mr-10"></i> Edit Profile</a></li>

    <li><a href="<?php echo base_url() ?>"> Back To Home</a></li>



    

  </ul>

</div>