<?php 
$config = array(
    'protocol' => 'smtp',
    'smtp_host' => 'mail.interspaceeducation.com', 
    'smtp_port' => 587,
    'smtp_user' => 'info@interspaceeducation.com',
    'smtp_pass' => 'interspace!@#$%',
    'mailtype' => 'text',
    'smtp_timeout' => '4', 
    'charset' => 'iso-8859-1',
    'wordwrap' => TRUE
);
?>